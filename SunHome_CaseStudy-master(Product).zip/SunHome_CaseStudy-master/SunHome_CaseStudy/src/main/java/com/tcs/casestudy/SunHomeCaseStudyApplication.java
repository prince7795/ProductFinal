package com.tcs.casestudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunHomeCaseStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunHomeCaseStudyApplication.class, args);
	}

}
