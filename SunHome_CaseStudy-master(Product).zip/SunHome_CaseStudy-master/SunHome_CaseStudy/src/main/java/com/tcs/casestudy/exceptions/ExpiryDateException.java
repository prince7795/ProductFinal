package com.tcs.casestudy.exceptions;

public class ExpiryDateException extends RuntimeException {

	public ExpiryDateException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}